# https://github.com/Jam302/jamshahrukh.git
# cd jamshahrukh
# chmod +x *
# ls
# python2 jam.py
